-- Adminer 4.7.7 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(20) NOT NULL,
  `password` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `admin` (`id`, `login`, `password`) VALUES
(1,	'admin',	'202cb962ac59075b964b07152d234b70');

DROP TABLE IF EXISTS `task`;
CREATE TABLE `task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(20) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `changed` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `task` (`id`, `user_name`, `user_email`, `description`, `status`, `changed`) VALUES
(1,	'test',	'test@test.test',	'test test ',	1,	NULL),
(2,	'test',	'test@test.test',	'test test ',	1,	NULL),
(3,	'test',	'test@test.test',	'test test ',	1,	NULL),
(4,	'test',	'test@test.test',	'test test ',	1,	NULL),
(5,	'test',	'test@test.test',	'test test ',	1,	NULL),
(6,	'test',	'test@test.test',	'test test ',	1,	NULL),
(7,	'test',	'test@test.test',	'test test ',	1,	NULL),
(8,	'test',	'test@test.test',	'test test ',	1,	NULL),
(9,	'test',	'test@test.test',	'test test ',	1,	NULL),
(10,	'hilary',	'test@test.test',	'test',	NULL,	NULL),
(11,	'reert',	'ertert',	'ertert',	NULL,	NULL),
(12,	'reert',	'ertert@rerter.ert',	'ertert',	NULL,	NULL),
(13,	'reert',	'ertert@rerter.ert',	'ertert',	NULL,	NULL),
(14,	'qwerqwe',	'qwerqwer',	'qwerqr',	NULL,	NULL),
(15,	'wrwer',	'werwer',	'werwer',	NULL,	NULL),
(16,	'werwer',	'werwer',	'werwerwerwer',	NULL,	NULL),
(17,	'fjfghjfg',	'hjfghjf',	'ghjfghjfgh',	NULL,	NULL),
(18,	'fjfghjfg',	'hjfghjf',	'ghjfghjfgh',	NULL,	NULL),
(19,	'sdfgdfghfjh',	'sfghdghjf',	'ghjfghjfghj',	NULL,	NULL),
(20,	',hklhjkl',	'hjkl',	'hjklhjkl',	NULL,	NULL),
(21,	'qwerqwer',	'qwerqwe',	'rqwer',	NULL,	NULL),
(22,	'qwerqwer',	'qwerqwe',	'rqwer',	NULL,	NULL),
(23,	'dsdf',	'gsdfgsdf',	'gsdfgs',	NULL,	NULL),
(24,	'dsdf',	'gsdfgsdf',	'gsdfgs',	NULL,	NULL),
(25,	'asdfasd',	'fasdfasdf',	'asdfasdfshfghdfghdfghdfgasdasdasdasdasdsadasda',	1,	NULL),
(26,	'asdfasd',	'fasdfasdf',	'asdfasdfrwerwer',	1,	NULL),
(27,	'test',	'test@test.job',	'test job',	NULL,	NULL),
(28,	'test',	'xsxcdvfifl_1580234923@tfbnw.net',	'test job',	NULL,	NULL),
(29,	'qwrwer',	'qwerqwe@werwe.ere',	'rqwerqwer',	1,	NULL),
(30,	'test',	'xsxcdvfifl_1580234923@tfbnw.net',	'&lt;script&gt;alert(&lsquo;test&rsquo;);&lt;/script&gt;',	NULL,	NULL),
(31,	'admin',	'kashalotta@yandex.ru',	'&lt;script&gt;alert(&lsquo;test&rsquo;);&lt;/script&gt;',	NULL,	NULL),
(32,	'admin',	'xsxcdvfifl_1580234923@tfbnw.net',	'&lt;script&gt;alert(&lsquo;test&rsquo;);&lt;/script&gt;werwerwer',	1,	NULL),
(33,	'admin',	'xsxcdvfifl_1580234923@tfbnw.net',	'&lt;script&gt;alert(&lsquo;test&rsquo;);&lt;/script&gt;rwerw',	1,	NULL),
(34,	',admin',	'xsxcdvfifl_1580234923@tfbnw.net',	'&lt;script&gt;alert(&lsquo;test&rsquo;);&lt;/script&gt;1112',	1,	1),
(35,	'wtrwe',	'test@test.test',	'rtwertwer',	NULL,	NULL),
(36,	'test',	'xsxcdvfifl_1580234923@tfbnw.net',	'fdsfdsf',	NULL,	NULL),
(37,	'test',	'test@test.test',	'adsfsdfasdf',	NULL,	NULL),
(38,	'task',	'kashalotta@yandex.ru',	'lkkyk',	NULL,	NULL),
(39,	'admin',	'qewrqwer@sadasd.asd',	'adASDASD',	NULL,	NULL),
(40,	'fasdfasdf',	'adsfasd@dsfasd.asdfasd',	'asdfasdfasd',	NULL,	NULL),
(41,	'test',	'xsxcdvfifl_1580234923@tfbnw.net',	'sdfgsdfgsdfg',	NULL,	NULL),
(42,	'task',	'kashalotta@yandex.ru',	'fafae',	NULL,	NULL),
(43,	'task',	'kashalotta@yandex.ru',	'fafae',	NULL,	NULL),
(44,	'admin',	'nimoto1991@gmail.com',	'zxcvzxcvzxcv',	NULL,	NULL),
(45,	'admin',	'kashalotta@yandex.ru',	'ZXcZX',	NULL,	NULL);

-- 2020-05-24 17:31:11
